﻿namespace AOgiaQGame
{
    partial class DesignForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DesignForm));
            this.toolboxPanel = new System.Windows.Forms.Panel();
            this.lblToolBox = new System.Windows.Forms.Label();
            this.picBoxRedDoor = new System.Windows.Forms.PictureBox();
            this.picBoxGreenDoor = new System.Windows.Forms.PictureBox();
            this.picBoxRedBox = new System.Windows.Forms.PictureBox();
            this.picBoxgreenBox = new System.Windows.Forms.PictureBox();
            this.picBoxWall = new System.Windows.Forms.PictureBox();
            this.picBoxNone = new System.Windows.Forms.PictureBox();
            this.lblRedDoor = new System.Windows.Forms.Label();
            this.lblGreenDoor = new System.Windows.Forms.Label();
            this.lblRedBox = new System.Windows.Forms.Label();
            this.lblGreenBox = new System.Windows.Forms.Label();
            this.lblWall = new System.Windows.Forms.Label();
            this.lblNone = new System.Windows.Forms.Label();
            this.generatePanel = new System.Windows.Forms.Panel();
            this.txtColumn = new System.Windows.Forms.TextBox();
            this.txtRow = new System.Windows.Forms.TextBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.lblColumn = new System.Windows.Forms.Label();
            this.lblRow = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panelGrid = new System.Windows.Forms.Panel();
            this.toolboxPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRedDoor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGreenDoor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRedBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxgreenBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxWall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxNone)).BeginInit();
            this.generatePanel.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolboxPanel
            // 
            this.toolboxPanel.Controls.Add(this.lblToolBox);
            this.toolboxPanel.Controls.Add(this.picBoxRedDoor);
            this.toolboxPanel.Controls.Add(this.picBoxGreenDoor);
            this.toolboxPanel.Controls.Add(this.picBoxRedBox);
            this.toolboxPanel.Controls.Add(this.picBoxgreenBox);
            this.toolboxPanel.Controls.Add(this.picBoxWall);
            this.toolboxPanel.Controls.Add(this.picBoxNone);
            this.toolboxPanel.Controls.Add(this.lblRedDoor);
            this.toolboxPanel.Controls.Add(this.lblGreenDoor);
            this.toolboxPanel.Controls.Add(this.lblRedBox);
            this.toolboxPanel.Controls.Add(this.lblGreenBox);
            this.toolboxPanel.Controls.Add(this.lblWall);
            this.toolboxPanel.Controls.Add(this.lblNone);
            this.toolboxPanel.Location = new System.Drawing.Point(40, 148);
            this.toolboxPanel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.toolboxPanel.Name = "toolboxPanel";
            this.toolboxPanel.Size = new System.Drawing.Size(125, 336);
            this.toolboxPanel.TabIndex = 0;
            // 
            // lblToolBox
            // 
            this.lblToolBox.AutoSize = true;
            this.lblToolBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToolBox.Location = new System.Drawing.Point(21, 14);
            this.lblToolBox.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblToolBox.Name = "lblToolBox";
            this.lblToolBox.Size = new System.Drawing.Size(78, 20);
            this.lblToolBox.TabIndex = 12;
            this.lblToolBox.Text = "Tool Box";
            // 
            // picBoxRedDoor
            // 
            this.picBoxRedDoor.Image = global::AOgiaQGame.Properties.Resources.Red_Door;
            this.picBoxRedDoor.Location = new System.Drawing.Point(18, 284);
            this.picBoxRedDoor.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picBoxRedDoor.Name = "picBoxRedDoor";
            this.picBoxRedDoor.Size = new System.Drawing.Size(42, 41);
            this.picBoxRedDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxRedDoor.TabIndex = 11;
            this.picBoxRedDoor.TabStop = false;
            this.picBoxRedDoor.Click += new System.EventHandler(this.picBoxRedDoor_Click);
            // 
            // picBoxGreenDoor
            // 
            this.picBoxGreenDoor.Image = global::AOgiaQGame.Properties.Resources.Green_Door;
            this.picBoxGreenDoor.Location = new System.Drawing.Point(18, 237);
            this.picBoxGreenDoor.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picBoxGreenDoor.Name = "picBoxGreenDoor";
            this.picBoxGreenDoor.Size = new System.Drawing.Size(42, 41);
            this.picBoxGreenDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxGreenDoor.TabIndex = 10;
            this.picBoxGreenDoor.TabStop = false;
            this.picBoxGreenDoor.Click += new System.EventHandler(this.picBoxGreenDoor_Click);
            // 
            // picBoxRedBox
            // 
            this.picBoxRedBox.Image = ((System.Drawing.Image)(resources.GetObject("picBoxRedBox.Image")));
            this.picBoxRedBox.Location = new System.Drawing.Point(18, 191);
            this.picBoxRedBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picBoxRedBox.Name = "picBoxRedBox";
            this.picBoxRedBox.Size = new System.Drawing.Size(42, 41);
            this.picBoxRedBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxRedBox.TabIndex = 9;
            this.picBoxRedBox.TabStop = false;
            this.picBoxRedBox.Click += new System.EventHandler(this.picBoxRedBox_Click);
            // 
            // picBoxgreenBox
            // 
            this.picBoxgreenBox.Image = ((System.Drawing.Image)(resources.GetObject("picBoxgreenBox.Image")));
            this.picBoxgreenBox.Location = new System.Drawing.Point(18, 145);
            this.picBoxgreenBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picBoxgreenBox.Name = "picBoxgreenBox";
            this.picBoxgreenBox.Size = new System.Drawing.Size(42, 41);
            this.picBoxgreenBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxgreenBox.TabIndex = 8;
            this.picBoxgreenBox.TabStop = false;
            this.picBoxgreenBox.Click += new System.EventHandler(this.picBoxgreenBox_Click);
            // 
            // picBoxWall
            // 
            this.picBoxWall.Image = global::AOgiaQGame.Properties.Resources.BrickWall2;
            this.picBoxWall.Location = new System.Drawing.Point(18, 98);
            this.picBoxWall.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picBoxWall.Name = "picBoxWall";
            this.picBoxWall.Size = new System.Drawing.Size(42, 41);
            this.picBoxWall.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxWall.TabIndex = 7;
            this.picBoxWall.TabStop = false;
            this.picBoxWall.Click += new System.EventHandler(this.picBoxWall_Click);
            // 
            // picBoxNone
            // 
            this.picBoxNone.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.picBoxNone.Location = new System.Drawing.Point(18, 52);
            this.picBoxNone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picBoxNone.Name = "picBoxNone";
            this.picBoxNone.Size = new System.Drawing.Size(42, 41);
            this.picBoxNone.TabIndex = 6;
            this.picBoxNone.TabStop = false;
            this.picBoxNone.Click += new System.EventHandler(this.picBoxNone_Click);
            // 
            // lblRedDoor
            // 
            this.lblRedDoor.AutoSize = true;
            this.lblRedDoor.Location = new System.Drawing.Point(64, 301);
            this.lblRedDoor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRedDoor.Name = "lblRedDoor";
            this.lblRedDoor.Size = new System.Drawing.Size(53, 13);
            this.lblRedDoor.TabIndex = 5;
            this.lblRedDoor.Text = "Red Door";
            // 
            // lblGreenDoor
            // 
            this.lblGreenDoor.AutoSize = true;
            this.lblGreenDoor.Location = new System.Drawing.Point(62, 254);
            this.lblGreenDoor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGreenDoor.Name = "lblGreenDoor";
            this.lblGreenDoor.Size = new System.Drawing.Size(59, 13);
            this.lblGreenDoor.TabIndex = 4;
            this.lblGreenDoor.Text = "GreenDoor";
            // 
            // lblRedBox
            // 
            this.lblRedBox.AutoSize = true;
            this.lblRedBox.Location = new System.Drawing.Point(64, 204);
            this.lblRedBox.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRedBox.Name = "lblRedBox";
            this.lblRedBox.Size = new System.Drawing.Size(48, 13);
            this.lblRedBox.TabIndex = 3;
            this.lblRedBox.Text = "Red Box";
            // 
            // lblGreenBox
            // 
            this.lblGreenBox.AutoSize = true;
            this.lblGreenBox.Location = new System.Drawing.Point(64, 156);
            this.lblGreenBox.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGreenBox.Name = "lblGreenBox";
            this.lblGreenBox.Size = new System.Drawing.Size(57, 13);
            this.lblGreenBox.TabIndex = 2;
            this.lblGreenBox.Text = "Green Box";
            // 
            // lblWall
            // 
            this.lblWall.AutoSize = true;
            this.lblWall.Location = new System.Drawing.Point(69, 113);
            this.lblWall.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWall.Name = "lblWall";
            this.lblWall.Size = new System.Drawing.Size(28, 13);
            this.lblWall.TabIndex = 1;
            this.lblWall.Text = "Wall";
            // 
            // lblNone
            // 
            this.lblNone.AutoSize = true;
            this.lblNone.Location = new System.Drawing.Point(64, 70);
            this.lblNone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNone.Name = "lblNone";
            this.lblNone.Size = new System.Drawing.Size(33, 13);
            this.lblNone.TabIndex = 0;
            this.lblNone.Text = "None";
            // 
            // generatePanel
            // 
            this.generatePanel.Controls.Add(this.txtColumn);
            this.generatePanel.Controls.Add(this.txtRow);
            this.generatePanel.Controls.Add(this.btnGenerate);
            this.generatePanel.Controls.Add(this.lblColumn);
            this.generatePanel.Controls.Add(this.lblRow);
            this.generatePanel.Location = new System.Drawing.Point(40, 62);
            this.generatePanel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.generatePanel.Name = "generatePanel";
            this.generatePanel.Size = new System.Drawing.Size(663, 61);
            this.generatePanel.TabIndex = 1;
            // 
            // txtColumn
            // 
            this.txtColumn.Location = new System.Drawing.Point(232, 19);
            this.txtColumn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtColumn.Name = "txtColumn";
            this.txtColumn.Size = new System.Drawing.Size(113, 20);
            this.txtColumn.TabIndex = 4;
            // 
            // txtRow
            // 
            this.txtRow.Location = new System.Drawing.Point(51, 19);
            this.txtRow.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtRow.Name = "txtRow";
            this.txtRow.Size = new System.Drawing.Size(118, 20);
            this.txtRow.TabIndex = 3;
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(526, 21);
            this.btnGenerate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(84, 23);
            this.btnGenerate.TabIndex = 2;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // lblColumn
            // 
            this.lblColumn.AutoSize = true;
            this.lblColumn.Location = new System.Drawing.Point(182, 21);
            this.lblColumn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblColumn.Name = "lblColumn";
            this.lblColumn.Size = new System.Drawing.Size(42, 13);
            this.lblColumn.TabIndex = 1;
            this.lblColumn.Text = "Column";
            // 
            // lblRow
            // 
            this.lblRow.AutoSize = true;
            this.lblRow.Location = new System.Drawing.Point(10, 21);
            this.lblRow.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRow.Name = "lblRow";
            this.lblRow.Size = new System.Drawing.Size(29, 13);
            this.lblRow.TabIndex = 0;
            this.lblRow.Text = "Row";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // menuStrip2
            // 
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip2.Size = new System.Drawing.Size(800, 24);
            this.menuStrip2.TabIndex = 4;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panelGrid
            // 
            this.panelGrid.BackColor = System.Drawing.Color.Transparent;
            this.panelGrid.Location = new System.Drawing.Point(188, 148);
            this.panelGrid.Name = "panelGrid";
            this.panelGrid.Size = new System.Drawing.Size(515, 361);
            this.panelGrid.TabIndex = 6;
            // 
            // DesignForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 574);
            this.Controls.Add(this.panelGrid);
            this.Controls.Add(this.generatePanel);
            this.Controls.Add(this.toolboxPanel);
            this.Controls.Add(this.menuStrip2);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "DesignForm";
            this.Text = "DesignForm";
            this.Load += new System.EventHandler(this.DesignForm_Load);
            this.toolboxPanel.ResumeLayout(false);
            this.toolboxPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRedDoor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGreenDoor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRedBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxgreenBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxWall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxNone)).EndInit();
            this.generatePanel.ResumeLayout(false);
            this.generatePanel.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel toolboxPanel;
        private System.Windows.Forms.Label lblGreenDoor;
        private System.Windows.Forms.Label lblRedBox;
        private System.Windows.Forms.Label lblGreenBox;
        private System.Windows.Forms.Label lblWall;
        private System.Windows.Forms.Label lblNone;
        private System.Windows.Forms.Panel generatePanel;
        private System.Windows.Forms.TextBox txtColumn;
        private System.Windows.Forms.TextBox txtRow;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Label lblColumn;
        private System.Windows.Forms.Label lblRow;
        private System.Windows.Forms.PictureBox picBoxNone;
        private System.Windows.Forms.Label lblRedDoor;
        private System.Windows.Forms.Label lblToolBox;
        private System.Windows.Forms.PictureBox picBoxRedDoor;
        private System.Windows.Forms.PictureBox picBoxGreenDoor;
        private System.Windows.Forms.PictureBox picBoxRedBox;
        private System.Windows.Forms.PictureBox picBoxgreenBox;
        private System.Windows.Forms.PictureBox picBoxWall;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip2;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panelGrid;
    }
}