﻿using System;
using System.Windows.Forms;

namespace AOgiaQGame
{
    public partial class QGameControlForm : Form
    {
        private DesignForm design;
        private PlayForm playForm;
        
        public QGameControlForm()
        {
            InitializeComponent();
        }

        private void btnDesign_Click(object sender, EventArgs e)
        {
            design = new DesignForm();
            design.ShowDialog();
        }

        private void QGameControlForm_Load(object sender, EventArgs e)
        {

        }

		private void btnPlay_Click(object sender, EventArgs e)
		{
            playForm = new PlayForm(design);
            playForm.Show();
		}

		private void btnExit_Click(object sender, EventArgs e)
		{
            Close();
		}
	}
}
