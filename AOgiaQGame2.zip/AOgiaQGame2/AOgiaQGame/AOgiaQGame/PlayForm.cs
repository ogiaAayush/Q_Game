﻿//Aayush Ogia
//Student Id: 8874123

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AOgiaQGame
{
	public partial class PlayForm : Form
	{
		// Declaration of private variables
		private DesignForm design;  // Reference to a DesignForm object
		private Grids grids;    // Reference to a Grids object for managing the game grid

		// Constructor for PlayForm that takes a DesignForm parameter

		public PlayForm(DesignForm designForm)
        {
            InitializeComponent();
            this.design = designForm;   // Initializing the DesignForm reference
			grids = new Grids(this, gridPanel);     // Initializing the Grids object for game management
												
            // Disabling movement buttons until a game is loaded
			btnDown.Enabled = false;
            btnUp.Enabled = false;
            btnRight.Enabled = false;
            btnLeft.Enabled = false;
        }

		// Event handler for the 'Up' movement button

		private void btnUp_Click(object sender, EventArgs e)
		{
            pgrids.BoxMovement(Grids.Navigations.Up);

        }

		// Event handler for the 'Left' movement button
		private void btnLeft_Click(object sender, EventArgs e)
		{
            grids.BoxMovement(Grids.Navigations.Left);

        }

		// Event handler for the 'Right' movement button
		private void btnRight_Click(object sender, EventArgs e)
		{
            grids.BoxMovement(Grids.Navigations.Right);

        }

		// Event handler for the 'Down' movement button
		private void btnDown_Click(object sender, EventArgs e)
		{
            grids.BoxMovement(Grids.Navigations.Down);

        }

		// Event handler for the 'Load' menu item
		private void loadToolStripMenuItem_Click(object sender, EventArgs e)
		{
			using (OpenFileDialog openFile = new OpenFileDialog())
			{
				openFile.Title = "LoadGame";
				openFile.Filter = "qGame Files | *.qGame";
				DialogResult dResult = openFile.ShowDialog();	

				if (dResult == DialogResult.OK)
				{
					string fileName = openFile.FileName;
					grids.LoadGame(fileName);   // Loading the game data from the specified file

					MovementAndCountUpdate();// Updating movement count and remaining box count
											 
                    // Enabling movement buttons after loading a game
					btnDown.Enabled = true;
					btnUp.Enabled = true;
					btnRight.Enabled = true;
					btnLeft.Enabled = true;

				}
                MovementAndCountUpdate();   // Updating movement count and remaining box count

			}
        }

		// Event handler for the 'Close' menu item
		private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
			Close();    // Closing the form
		}

		// Method to retrieve the current movement count
		public int Count()
        {
            return grids.count;
        }

		// Method to retrieve the remaining boxes count
		public int BoxRemaindar()
        {
            return grids.remainingBoxes;
        }

		// Method to update movement count and remaining box count on the UI
		public void MovementAndCountUpdate()
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() => MovementAndCountUpdate()));
                return;
            }

			// Checking if grids, txtBoxMovesNmbr, and txtBoxRemainBoxes are not null
			if (grids != null && txtBoxMovesNmbr != null && txtBoxRemainBoxes != null)
            {
                txtBoxMovesNmbr.Text = Count().ToString();

				// Update the remaining boxes count text box
				txtBoxRemainBoxes.Text = BoxRemaindar().ToString();
            }
        }
    }
}
