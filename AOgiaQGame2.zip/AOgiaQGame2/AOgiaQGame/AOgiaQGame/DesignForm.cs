﻿//Aayush Ogia
//Student Id: 8874123

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace AOgiaQGame
{
    public partial class DesignForm : Form
    {
		// Declarations of private variables

		private Grids grids;
        private PlayForm playForm;
        private bool currentLevel;
        private int currentToolValue;
        public int Columns { get; private set; }
        public int Rows { get; private set; }

		// Constructor for the DesignForm class
		public DesignForm()
        {
            InitializeComponent();
            grids = new Grids(playForm, panelGrid); // Initialize Grids for designing
        }

		// Event handler for generating a new grid
		private void btnGenerate_Click(object sender, EventArgs e)
        {
            // Get the user input for the number of rows and columns
            string row = txtRow.Text;
            string column = txtColumn.Text;

            // Check if the input can be parsed into integers
            if (!int.TryParse(row, out int rows) || !int.TryParse(column, out int columns))
            {
                // Show an error message if the input is not valid
                MessageBox.Show("Please provide valid data for Rows and Columns (Both must be integers) Input string was not in a correct format.",
                    "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (rows < 1 || columns < 1)
            {
                // Show an error message if the input is not positive
                MessageBox.Show("Please provide valid data for Rows and Columns (Both must be integers) Numbers must be positive.",
                    "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (currentLevel == true)
                {
                    // Ask the user if they want to create a new level and inform them that the current level will be lost.
                    DialogResult R = MessageBox.Show("Do you want to create a new level? If you do, the current level will be lost.", "QGame", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (R == DialogResult.Yes)
                    {
                        grids.RowColumnGenerator(rows, columns);// Generate a new grid with the specified rows and columns
                    }
                }
                else
                {
                    grids.RowColumnGenerator(rows, columns); // Generate a new grid with the specified rows and columns

                    currentLevel = true; // Set the flag to indicate that a level is being designed
                }
            }
        }
       

  		// Method to set the selected tool and its associated image
		private void ToolSelector(Grids.AllTools allTools, Image image)
        {
            grids.CurrentTool = image;

            currentToolValue = (int)allTools;
        }

        // Calculate the number of grid cells with a specific tool
        private int RowColumnCalculator(int toolNumber)
        {
            int count = 0;
            foreach (PictureBox clickTool in grids.PicBoxGrids)
            {
                if (clickTool.Tag is Grids.AllTools toolsTag)
                {
                    if ((int)toolsTag == toolNumber)
                    {
                        count++;
                    }
                }
            }
            return count;
        }

        // Event handlers for selecting different tools
        private void picBoxNone_Click(object sender, EventArgs e)
        {
            ToolSelector(Grids.AllTools.None, null); // Select the "None" tool
        }

        private void picBoxWall_Click(object sender, EventArgs e)
        {
            ToolSelector(Grids.AllTools.Wall, Properties.Resources.BrickWall2); // Select the "Wall" tool
        }

        private void picBoxgreenBox_Click(object sender, EventArgs e)
        {
            ToolSelector(Grids.AllTools.GreenBox, Properties.Resources.Green_Box); // Select the "GreenBox" tool
        }

        private void picBoxRedBox_Click(object sender, EventArgs e)
        {
            ToolSelector(Grids.AllTools.RedBox, Properties.Resources.Red_Box); // Select the "RedBox" tool
        }

        private void picBoxGreenDoor_Click(object sender, EventArgs e)
        {
            ToolSelector(Grids.AllTools.GreenDoor, Properties.Resources.Green_Door); // Select the "GreenDoor" tool
        }

        private void picBoxRedDoor_Click(object sender, EventArgs e)
        {
            ToolSelector(Grids.AllTools.RedDoor, Properties.Resources.Red_Door); // Select the "RedDoor" tool
        }

		// Event handler to save the designed level to a file
		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
			// Save the designed level to a file

			using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Title = "SaveGame";
                saveFileDialog.Filter = "QGame Files | *.qGame";
                DialogResult R = saveFileDialog.ShowDialog();

                switch (R)
                {
                    case DialogResult.None:
                        break;
                    case DialogResult.OK:
                        string row = txtRow.Text;
                        string column = txtColumn.Text;
                        int rows, cols;

                        if (int.TryParse(row, out rows) && int.TryParse(column, out cols))
                        {
                            string file = saveFileDialog.FileName;

                            if (!file.EndsWith(".qGame"))
                            {
                                file += ".qGame";
                            }
                            Save(file, rows, cols);

                            // Display information about the saved file and the contents of the grid
                            string info = $"File saved successfully\n" +
                                $"Total Number of Walls = {RowColumnCalculator((int)Grids.AllTools.Wall)}\n" +
                                $"Total Number of Boxes = {RowColumnCalculator((int)Grids.AllTools.GreenBox) + RowColumnCalculator((int)Grids.AllTools.RedBox)}\n" +
                                $"Total Number of Doors = {RowColumnCalculator((int)Grids.AllTools.GreenDoor) + RowColumnCalculator((int)Grids.AllTools.RedDoor)}\n";

                            MessageBox.Show(info, "AOgiaQGame", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        break;
                    default:
                        break;
                }
            }
        }

		// Method to save the designed level to a file
		private void Save(string fileName, int rows, int columns)
        {
			// Code to save the designed level with grid contents to a file

			using (StreamWriter sw = new StreamWriter(fileName))
            {
                sw.WriteLine(rows);
                sw.WriteLine(columns);

                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < columns; j++)
                    {
                        PictureBox p = grids.PicBoxGrids[i*columns + j];

                        if (p.Tag is Grids.AllTools toolNumber)
                        {
                            sw.WriteLine(i);
                            sw.WriteLine(j);
                            sw.WriteLine((int)toolNumber);
                        }
                        else
                        {
                            sw.WriteLine(i);
                            sw.WriteLine(j);
                            sw.WriteLine((int)Grids.AllTools.None);
                        }
                    }
                }
            }
        }

        
        // Event handler for closing the application
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();    // Close the application
		}

		private void DesignForm_Load(object sender, EventArgs e)
		{

		}
	}
}