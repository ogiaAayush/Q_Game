﻿//Aayush Ogia
//Student Id: 8874123

using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace AOgiaQGame
{
    public class Grids 
	{
		// Private variables declaration
		private int invalidMove = 0;
		private DesignForm design; 
        private PlayForm playForm;
        public int boxRows;
		public int boxColumns;
        public Image CurrentTool;
        private Panel gridPanel;
        public List<PictureBox> PicBoxGrids;
        List<PictureBox> MoveBoxes = new List<PictureBox>();
        public int count;
        public int remainingBoxes;
        private int Columns;
        private int Rows;

		// Stage flags for design and play modes
		public bool InPlayStage {  get; set; }
        public bool InDesignStage { get; set; }

		// Properties for the grid panel
		public Panel GridPanel { get => gridPanel; set => gridPanel = value; }

		// Constructor for Grids class
		public Grids(PlayForm playForm, Panel gridPanel)
        {
            this.playForm = playForm;
            this.GridPanel = gridPanel;
            PicBoxGrids = new List<PictureBox>();
        }

		// Enumeration for directions
		public enum Navigations
        {
            Up,
            Left,
            Right,
            Down
        }

        // Enum to represent the available tools
        public enum AllTools
        {
            None = 1,
            Wall = 2,
            GreenBox = 3,
            RedBox = 4,
            GreenDoor = 5,
            RedDoor = 6
        }

        // A dictionary to map tool enums to their corresponding images
        public Dictionary<AllTools, Image> matchingImage = new Dictionary<AllTools, Image>
        {
            {AllTools.None, null},
            {AllTools.Wall, Properties.Resources.BrickWall2},
            {AllTools.GreenBox, Properties.Resources.Green_Box},
            {AllTools.RedBox, Properties.Resources.Red_Box},
            {AllTools.GreenDoor, Properties.Resources.Green_Door},
            {AllTools.RedDoor, Properties.Resources.Red_Door},
        };


        // Check if two images are equal
        public bool CheckImage(Image picture1, Image picture2)
        {
			// Implementation to compare two images

			if (picture1 == null || picture2 == null)
            {
                return false;
            }
            using (MemoryStream ms = new MemoryStream())
            using (MemoryStream ms1 = new MemoryStream())
            {
                picture1.Save(ms, picture1.RawFormat);
                picture2.Save(ms1, picture2.RawFormat);

                byte[] data1 = ms.ToArray();
                byte[] data2 = ms1.ToArray();

                if (data1.Length != data2.Length)
                {
                    return false;
                }

                for (int i = 0; i < data1.Length; i++)
                {
                    if (data1[i] != data2[i])
                    {
                        return false;
                    }
                }
                return true;
            }
        }

		// Method to generate rows and columns for the grid
		public void RowColumnGenerator(int numRows, int numColumns)
        {
			// Implementation to generate rows and columns for the grid

			GridPanel.Controls.Clear();
            PicBoxGrids.Clear();
            Rows = numRows;
            Columns = numColumns;

            if (numColumns > 0)
            {
                int widthCells = GridPanel.Width / numColumns;

                if (numRows > 0)
                {
                    int heightCells = GridPanel.Height / numRows;

                    // Create PictureBox controls to represent the grid cells
                    for (int i = 0; i < numRows; i++)
                    {
                        for (int j = 0; j < numColumns; j++)
                        {
                            PictureBox p = new PictureBox();
                            p.Width = widthCells;
                            p.Height = heightCells;
                            p.Location = new Point(j * widthCells, i * heightCells);
                            p.SizeMode = PictureBoxSizeMode.StretchImage;
                            p.BorderStyle = BorderStyle.Fixed3D;
                            p.Click += Grids_Click; // Attach a click event handler to the PictureBox

                            PicBoxGrids.Add(p); // Add the PictureBox to the list
                            GridPanel.Controls.Add(p); // Add the PictureBox to the grid panel
                        }
                    }
                }
            }
        }

		// Method to load a game from a file
		public void LoadGame(string fileName)
        {
			// Implementation to load game data from a file

			if (File.Exists(fileName))
            {
                using (StreamReader read = new StreamReader(fileName))
                {
                    playStage();

                    int boxes = 0;

                    if (int.TryParse(read.ReadLine(), out int row) && int.TryParse(read.ReadLine(), out int col))
                    {
                       RowColumnGenerator(row, col);

                        for (int i = 0; i < row; i++)
                        {
                            for (int j = 0; j < col; j++)
                            {
                                if (int.TryParse(read.ReadLine(), out int loadedRows)
                                    && int.TryParse(read.ReadLine(), out int loadedCols)
                                    && int.TryParse(read.ReadLine(), out int loadedTools))
                                {
                                    PictureBox box = getCell(loadedRows, loadedCols);
                                    if (box != null)
                                    {

                                        if (Enum.IsDefined(typeof(AllTools), loadedTools))
                                        {

                                            box.Tag = loadedTools;
                                            box.Image = matchingImage[(AllTools)loadedTools];

                                            if (loadedTools == (int)AllTools.GreenBox || loadedTools == (int)AllTools.RedBox)
                                            {
                                                boxes++;
                                            }
                                        }
                                    }
    
                                }

                            }
                        }
                        updateGetBoxPosition();
                        remainingBoxes = boxes;
                        count = 0;
                        if (playForm != null)
                        {
                            playForm.MovementAndCountUpdate();
                        }
                    }
                }
            }
        }

		// Method to switch to the design stage
		public void designStage()
		{
			// Switching to design stage

			InDesignStage = true;
			InPlayStage = false;
		}

		// Method to switch to the play stage
		public void playStage()
		{
			// Switching to play stage

			InDesignStage = false;
			InPlayStage = true;
		}

		// Method to handle design actions on the grid
		public void handleDesign(PictureBox clickedCell)
        {
			// Implementation to handle design actions

			if (CurrentTool != null)
            {
                foreach (var item in matchingImage)
                {
                    if (CheckImage(CurrentTool, item.Value))
                    {

                        clickedCell.Tag = item.Key; // Set the tag of the PictureBox to the selected tool
                        clickedCell.Image = item.Value; // Set the image of the PictureBox
                    }
                }
            }
            else
            {
                clickedCell.Tag = AllTools.None;
                clickedCell.Image = null;
            }
        }

		// Method to handle play actions on the grid
		public void handlePlay(PictureBox clickedCell)
        {
			// Implementation to handle play actions

			if (clickedCell.Tag is int Key)
            {
                if (Key == (int)AllTools.GreenBox || Key == (int)AllTools.RedBox)
                {
                    getBoxPosition(PicBoxGrids.IndexOf(clickedCell) / Columns, PicBoxGrids.IndexOf(clickedCell) % Columns);

                    highlightBox(clickedCell);
                }
            }
        }


		// Method to get the position of a box on the grid
		public void getBoxPosition(int row, int col)
		{
			// Getting box position

			boxRows = row;
			boxColumns = col;
			MoveBoxes.Clear();
			MoveBoxes.Add(getCell(boxRows, boxColumns));
		}

		// Method to update the selected box position
		public void updateGetBoxPosition()
		{
			// Updating the selected box position

			highlightBox(getCell(boxRows, boxColumns));
		}

		// Method to highlight a specific box on the grid

		public void highlightBox(PictureBox clickedCell)
        {
			// Highlighting a box on the grid

			foreach (PictureBox box in PicBoxGrids)
            {
                box.BorderStyle = BorderStyle.None;
            }

            if (clickedCell != null && clickedCell.Tag is int loadedTools)
            {
                if (loadedTools == (int)AllTools.GreenBox || loadedTools == (int)AllTools.RedBox)
                {
                    clickedCell.BorderStyle = BorderStyle.Fixed3D;
                }
            }

        }

        // Event handler for when a grid cell (PictureBox) is clicked
        public void Grids_Click(object sender, EventArgs e)
        {
            if (sender is PictureBox clickTool)
            {
                if (!InPlayStage)
                {
                    handleDesign(clickTool);
                }
                else if (!InDesignStage)
                {
                    handlePlay(clickTool);
                }

            }
        }

		// Method to retrieve a specific cell (PictureBox) from the grid
		public PictureBox getCell(int cellRow, int cellColumn)
        {
			// Retrieving a cell from the grid

			int index = cellRow * Columns + cellColumn;

            if (cellRow >= 0 && cellRow < Rows && cellColumn >= 0 && cellColumn < Columns)
            {

                return PicBoxGrids[index];
            }

            return null;

        }

		// Method to handle box movement in different directions
		public void BoxMovement(Navigations nav)
        {
			// Handling box movement in different directions

			int moveRows = boxRows;
            int moveColumns = boxColumns;
            bool moveStarted = false;
            bool movementFinished = false;

            while (IsWithin(moveRows, moveColumns))
            {
                // Update position based on navigation direction
                switch (nav)
                {
                    case Navigations.Up:
                        moveRows--;
                        break;
                    case Navigations.Down:
                        moveRows++;
                        break;
                    case Navigations.Left:
                        moveColumns--;
                        break;
                    case Navigations.Right:
                        moveColumns++;
                        break;
                }

                // Check if the new position is within the grid bounds
                if (!IsWithin(moveRows, moveColumns))
                {
                    MessageBox.Show("Please select a box.", "Qgame", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                    break; // Return if out of bounds
                }

                PictureBox movedCell = getCell(boxRows, boxColumns);
                PictureBox destinationCell = getCell(moveRows, moveColumns);

                if (IsAllowed(movedCell, destinationCell))
                {
                    if (!moveStarted)
                    {
                        // Update the moves count only when movement starts
                        count++;
                        moveStarted = true;
                    }

                    // Update the Tag and Image properties
                    destinationCell.Tag = movedCell.Tag;
                    destinationCell.Image = movedCell.Image;

                    // Clear the old position
                    movedCell.Tag = AllTools.None;
                    movedCell.Image = null;

                    // Update the selected box position
                    boxRows = moveRows;
                    boxColumns = moveColumns;

                    destinationCell.BringToFront();

                    // After each move, update the selected box position
                    highlightBox(destinationCell);
                    updateGetBoxPosition();

                    // Call the UI update method in your GamePlayForm
                    if (playForm != null)
                    {
                        playForm.MovementAndCountUpdate();
                    }
                }
                else
                {
                    if (!movementFinished)
                    {
                        movementFinished = true;

                        break; // Break the loop if a collision occurs
                    }
                }

                // Check if all boxes have been removed
                if (remainingBoxes == 0)
                {
                    // Show game end message
                    MessageBox.Show("No boxes Left!\n Game Over", "AayushQgame", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Remove remaining walls and doors
                    foreach (PictureBox box in PicBoxGrids)
                    {
                        if (box.Tag is int key && (key == (int)AllTools.Wall || key == (int)AllTools.GreenDoor || key == (int)AllTools.RedDoor))
                        {
                            box.Tag = AllTools.None;
                            box.Image = null;
                        }
                    }

                    // Reset scores
                    count = 0;
                    remainingBoxes = 0;
                    if (playForm != null)
                    {
                        playForm.MovementAndCountUpdate();
                    }
                }
            }

        }

		// Method to check if a move is allowed
		private bool IsAllowed(PictureBox clickedCell, PictureBox destinationCell)
        {
			// Checking if a move is allowed

			if (destinationCell.Tag is int Key)
            {
                if (clickedCell.Tag is int sourceKey)
                {
                    if (Key == (int)AllTools.None && sourceKey == Key)
                    {
                        // Same color box moving, always allowed
                        return true;
                    }

                    //  check for hitting an obstacle condition
                    if (sourceKey == (int)AllTools.RedBox && Key == (int)AllTools.GreenBox
                        || sourceKey == (int)AllTools.GreenBox && Key == (int)AllTools.RedBox
                        || sourceKey == (int)AllTools.RedBox && Key == (int)AllTools.RedBox
                        || sourceKey == (int)AllTools.GreenBox && Key == (int)AllTools.GreenBox)
                    {
                        return false;
                    }

                    // Moving a box to its matching door is allowed
                    if ((sourceKey == (int)AllTools.GreenBox && Key == (int)AllTools.GreenDoor) ||
                        (sourceKey == (int)AllTools.RedBox && Key == (int)AllTools.RedDoor))
                    {

                        if ((Key == (int)AllTools.GreenDoor || Key == (int)AllTools.RedDoor))
                        {
                            remainingBoxes--;

                            playForm.MovementAndCountUpdate();

                            // Clear the old position
                            clickedCell.Tag = AllTools.None;
                            clickedCell.Image = null;

							/*clickedCell.Tag = "invalidMove";*/

							// Highlight the selected box based on the updated position
							highlightBox(clickedCell);

                            // Indicate that the move is not allowed anymore
                            return false;
                        }
                    }
                }

                if (Key == (int)AllTools.Wall || Key == (int)AllTools.GreenDoor || Key == (int)AllTools.RedDoor)
                {
                    // Collision with a wall or door of a different color
                    return false;
                }
            }

            // Empty cell or non-box cell, always allowed
            return true;
        }

		// Method to check if a position is within the grid bounds
		private bool IsWithin(int cellRow, int cellColumn)
        {
			// Checking if a position is within the grid bounds

			return cellRow >= 0 && cellRow < Rows && cellColumn >= 0 && cellColumn < Columns;
        }
    }
}
