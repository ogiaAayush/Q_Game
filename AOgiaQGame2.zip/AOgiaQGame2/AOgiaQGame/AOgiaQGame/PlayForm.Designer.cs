﻿namespace AOgiaQGame
{
	partial class PlayForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gridPanel = new System.Windows.Forms.Panel();
			this.lblMovesNmbr = new System.Windows.Forms.Label();
			this.lblRemainBoxes = new System.Windows.Forms.Label();
			this.txtBoxMovesNmbr = new System.Windows.Forms.TextBox();
			this.txtBoxRemainBoxes = new System.Windows.Forms.TextBox();
			this.btnUp = new System.Windows.Forms.Button();
			this.btnLeft = new System.Windows.Forms.Button();
			this.btnRight = new System.Windows.Forms.Button();
			this.btnDown = new System.Windows.Forms.Button();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// gridPanel
			// 
			this.gridPanel.Location = new System.Drawing.Point(22, 42);
			this.gridPanel.Margin = new System.Windows.Forms.Padding(2);
			this.gridPanel.Name = "gridPanel";
			this.gridPanel.Size = new System.Drawing.Size(528, 444);
			this.gridPanel.TabIndex = 0;
			// 
			// lblMovesNmbr
			// 
			this.lblMovesNmbr.AutoSize = true;
			this.lblMovesNmbr.Location = new System.Drawing.Point(567, 42);
			this.lblMovesNmbr.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblMovesNmbr.Name = "lblMovesNmbr";
			this.lblMovesNmbr.Size = new System.Drawing.Size(71, 13);
			this.lblMovesNmbr.TabIndex = 1;
			this.lblMovesNmbr.Text = "No of Moves:";
			// 
			// lblRemainBoxes
			// 
			this.lblRemainBoxes.AutoSize = true;
			this.lblRemainBoxes.Location = new System.Drawing.Point(569, 130);
			this.lblRemainBoxes.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblRemainBoxes.Name = "lblRemainBoxes";
			this.lblRemainBoxes.Size = new System.Drawing.Size(121, 13);
			this.lblRemainBoxes.TabIndex = 2;
			this.lblRemainBoxes.Text = "No of Remaining Boxes:";
			// 
			// txtBoxMovesNmbr
			// 
			this.txtBoxMovesNmbr.Location = new System.Drawing.Point(569, 69);
			this.txtBoxMovesNmbr.Margin = new System.Windows.Forms.Padding(2);
			this.txtBoxMovesNmbr.Name = "txtBoxMovesNmbr";
			this.txtBoxMovesNmbr.Size = new System.Drawing.Size(150, 20);
			this.txtBoxMovesNmbr.TabIndex = 3;
			// 
			// txtBoxRemainBoxes
			// 
			this.txtBoxRemainBoxes.Location = new System.Drawing.Point(569, 162);
			this.txtBoxRemainBoxes.Margin = new System.Windows.Forms.Padding(2);
			this.txtBoxRemainBoxes.Name = "txtBoxRemainBoxes";
			this.txtBoxRemainBoxes.Size = new System.Drawing.Size(150, 20);
			this.txtBoxRemainBoxes.TabIndex = 4;
			// 
			// btnUp
			// 
			this.btnUp.Location = new System.Drawing.Point(619, 345);
			this.btnUp.Margin = new System.Windows.Forms.Padding(2);
			this.btnUp.Name = "btnUp";
			this.btnUp.Size = new System.Drawing.Size(56, 41);
			this.btnUp.TabIndex = 5;
			this.btnUp.Text = "UP";
			this.btnUp.UseVisualStyleBackColor = true;
			this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
			// 
			// btnLeft
			// 
			this.btnLeft.Location = new System.Drawing.Point(559, 397);
			this.btnLeft.Margin = new System.Windows.Forms.Padding(2);
			this.btnLeft.Name = "btnLeft";
			this.btnLeft.Size = new System.Drawing.Size(56, 41);
			this.btnLeft.TabIndex = 6;
			this.btnLeft.Text = "LEFT";
			this.btnLeft.UseVisualStyleBackColor = true;
			this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
			// 
			// btnRight
			// 
			this.btnRight.Location = new System.Drawing.Point(680, 397);
			this.btnRight.Margin = new System.Windows.Forms.Padding(2);
			this.btnRight.Name = "btnRight";
			this.btnRight.Size = new System.Drawing.Size(56, 41);
			this.btnRight.TabIndex = 7;
			this.btnRight.Text = "RIGHT";
			this.btnRight.UseVisualStyleBackColor = true;
			this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
			// 
			// btnDown
			// 
			this.btnDown.Location = new System.Drawing.Point(620, 397);
			this.btnDown.Margin = new System.Windows.Forms.Padding(2);
			this.btnDown.Name = "btnDown";
			this.btnDown.Size = new System.Drawing.Size(56, 41);
			this.btnDown.TabIndex = 8;
			this.btnDown.Text = "DOWN";
			this.btnDown.UseVisualStyleBackColor = true;
			this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
			// 
			// menuStrip1
			// 
			this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
			this.menuStrip1.Size = new System.Drawing.Size(744, 24);
			this.menuStrip1.TabIndex = 9;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.closeToolStripMenuItem});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
			this.fileToolStripMenuItem.Text = "File";
			// 
			// loadToolStripMenuItem
			// 
			this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
			this.loadToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
			this.loadToolStripMenuItem.Text = "Load";
			this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
			// 
			// closeToolStripMenuItem
			// 
			this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
			this.closeToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
			this.closeToolStripMenuItem.Text = "Close";
			this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
			// 
			// PlayForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(744, 505);
			this.Controls.Add(this.btnDown);
			this.Controls.Add(this.btnRight);
			this.Controls.Add(this.btnLeft);
			this.Controls.Add(this.btnUp);
			this.Controls.Add(this.txtBoxRemainBoxes);
			this.Controls.Add(this.txtBoxMovesNmbr);
			this.Controls.Add(this.lblRemainBoxes);
			this.Controls.Add(this.lblMovesNmbr);
			this.Controls.Add(this.gridPanel);
			this.Controls.Add(this.menuStrip1);
			this.MainMenuStrip = this.menuStrip1;
			this.Margin = new System.Windows.Forms.Padding(2);
			this.Name = "PlayForm";
			this.Text = "PlayForm";
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel gridPanel;
		private System.Windows.Forms.Label lblMovesNmbr;
		private System.Windows.Forms.Label lblRemainBoxes;
		private System.Windows.Forms.TextBox txtBoxMovesNmbr;
		private System.Windows.Forms.TextBox txtBoxRemainBoxes;
		private System.Windows.Forms.Button btnUp;
		private System.Windows.Forms.Button btnLeft;
		private System.Windows.Forms.Button btnRight;
		private System.Windows.Forms.Button btnDown;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
	}
}